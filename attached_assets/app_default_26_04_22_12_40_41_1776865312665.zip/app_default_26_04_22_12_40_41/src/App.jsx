import React, { useState, useRef, useEffect } from 'react';
import './index.css';

const App = () => {
  const [view, setView] = useState('login');
  const [tool, setTool] = useState('pen');
  const [color, setColor] = useState('#3b82f6');
  const [size, setSize] = useState(5);
  const [isDrawing, setIsDrawing] = useState(false);
  const [copied, setCopied] = useState(false);
  
  const canvasRef = useRef(null);
  const ctxRef = useRef(null);
  const historyRef = useRef([]);

  useEffect(() => {
    if (view === 'drawing' && canvasRef.current) {
      const canvas = canvasRef.current;
      const parent = canvas.parentElement;
      canvas.width = parent.clientWidth;
      canvas.height = parent.clientHeight;
      const ctx = canvas.getContext('2d', { willReadFrequently: true });
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctxRef.current = ctx;
      saveState();
    }
  }, [view]);

  const saveState = () => {
    if (ctxRef.current) {
      const imageData = ctxRef.current.getImageData(0, 0, canvasRef.current.width, canvasRef.current.height);
      historyRef.current.push(imageData);
      if (historyRef.current.length > 30) historyRef.current.shift();
    }
  };

  const undo = () => {
    if (historyRef.current.length > 1) {
      historyRef.current.pop();
      const lastState = historyRef.current[historyRef.current.length - 1];
      ctxRef.current.putImageData(lastState, 0, 0);
    }
  };

  const startDrawing = ({ nativeEvent }) => {
    const { offsetX, offsetY } = nativeEvent;
    saveState();
    ctxRef.current.beginPath();
    ctxRef.current.moveTo(offsetX, offsetY);
    setIsDrawing(true);
  };

  const draw = ({ nativeEvent }) => {
    if (!isDrawing) return;
    const { offsetX, offsetY } = nativeEvent;
    ctxRef.current.strokeStyle = tool === 'eraser' ? '#ffffff' : color;
    ctxRef.current.lineWidth = size;
    ctxRef.current.lineTo(offsetX, offsetY);
    ctxRef.current.stroke();
  };

  const copyLink = () => {
    navigator.clipboard.writeText("https://dualdoodle.app/invite/vX92kL");
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // --- UI VIEWS ---

  if (view === 'login') {
    return (
      <div className="auth-wrapper">
        <div className="orb orb-1"></div>
        <div className="orb orb-2"></div>
        <div className="glass-card auth-card">
          <div className="logo-section">
            <span className="logo-icon">🎨</span>
            <h1>Dual Doodle</h1>
            <p>Collaborative Art Platform</p>
          </div>
          <form onSubmit={(e) => { e.preventDefault(); setView('lobby'); }} className="auth-form">
            <div className="input-group">
              <i className="fas fa-user"></i>
              <input type="text" placeholder="Username" required />
            </div>
            <div className="input-group">
              <i className="fas fa-lock"></i>
              <input type="password" placeholder="Password" required />
            </div>
            <button type="submit" className="btn-glow">Sign In to Create</button>
          </form>
          <div className="auth-footer">Don't have an account? <span>Sign Up</span></div>
        </div>
      </div>
    );
  }

  if (view === 'lobby') {
    return (
      <div className="auth-wrapper">
        <div className="glass-card lobby-card">
          <h2>Room Ready</h2>
          <p>Your collaborative canvas is prepared.</p>
          <div className="invite-container">
            <div className="link-box">dualdoodle.app/invite/vX92kL</div>
            <button className={`btn-copy ${copied ? 'copied' : ''}`} onClick={copyLink}>
              {copied ? <i className="fas fa-check"></i> : <i className="fas fa-copy"></i>}
            </button>
          </div>
          <button onClick={() => setView('drawing')} className="btn-glow">Launch Workspace</button>
          <div className="status-badge"><span className="pulse"></span> Connected to Server</div>
        </div>
      </div>
    );
  }

  return (
    <div className="editor-layout">
      <nav className="top-bar">
        <div className="brand">Dual Doodle <span>PRO</span></div>
        <div className="session-info">
          <div className="avatars">
            <div className="avatar user-1">JD</div>
            <div className="avatar user-2">?</div>
          </div>
          <button className="btn-share" onClick={() => setView('lobby')}>Invite</button>
        </div>
      </nav>
      
      <div className="workspace">
        <aside className="floating-toolbar">
          <button className={tool === 'pen' ? 'active' : ''} onClick={() => setTool('pen')} title="Pen Tool">
            <i className="fas fa-pen"></i>
          </button>
          <button className={tool === 'eraser' ? 'active' : ''} onClick={() => setTool('eraser')} title="Eraser">
            <i className="fas fa-eraser"></i>
          </button>
          <div className="divider"></div>
          <button onClick={undo} title="Undo">
            <i className="fas fa-undo"></i>
          </button>
          <div className="divider"></div>
          <input type="color" value={color} onChange={(e
import React, { useEffect, useRef, useState } from 'react';
import { useParams, useSearchParams, useNavigate } from 'react-router-dom';
import { socket, connectSocket, disconnectSocket } from '../../services/socket';
import { 
  Palette, 
  Eraser, 
  Square, 
  Circle, 
  Minus, 
  Trash2, 
  Download, 
  XCircle, 
  Image as ImageIcon,
  Users
} from 'lucide-react';
import axios from 'axios';

const DrawingBoard = ({ user }) => {
  const { roomCode } = useParams();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const role = searchParams.get('role'); // 'creator' or 'joiner'

  const canvasRef = useRef(null);
  const contextRef = useRef(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [brushColor, setBrushColor] = useState('#6366f1');
  const [brushSize, setBrushSize] = useState(5);
  const [tool, setTool] = useState('pen'); // pen, eraser, rectangle, circle, line
  const [partner, setPartner] = useState(null);
  const [referenceImg, setReferenceImg] = useState(null);
  const [startPos, setStartPos] = useState({ x: 0, y: 0 });

  // For remote drawing, we need a separate reference to avoid context switching bugs
  const remoteContextRef = useRef(null);

  useEffect(() => {
    connectSocket();
    
    if (role === 'creator') {
      socket.emit('create-room', { roomCode, username: user.username });
    } else {
      socket.emit('join-room', { roomCode, username: user.username });
    }

    socket.on('user-joined', ({ creator, joiner }) => {
      setPartner(role === 'creator' ? joiner : creator);
    });

    socket.on('remote-draw', (data) => {
      drawRemote(data);
    });

    socket.on('reference-updated', (img) => {
      setReferenceImg(img);
    });

    socket.on('remote-clear', () => {
      clearCanvas(false);
    });

    socket.on('session-ended', () => {
      alert('The partner has ended the session.');
      navigate('/');
    });

    socket.on('error', (msg) => {
      alert(msg);
      navigate('/');
    });

    initCanvas();

    return () => {
      socket.off('user-joined');
      socket.off('remote-draw');
      socket.off('reference-updated');
      socket.off('remote-clear');
      socket.off('session-ended');
      socket.off('error');
      disconnectSocket();
    };
  }, [roomCode, role]);

  const initCanvas = () => {
    const canvas = canvasRef.current;
    canvas.width = window.innerWidth * 0.8;
    canvas.height = window.innerHeight * 0.7;
    
    const context = canvas.getContext('2d');
    context.lineCap = 'round';
    context.lineJoin = 'round';
    contextRef.current = context;
    
    // Draw center dividing line
    drawDivider(context, canvas.width, canvas.height);
  };

  const drawDivider = (ctx, w, h) => {
    ctx.beginPath();
    ctx.setLineDash([5, 5]);
    ctx.moveTo(w / 2, 0);
    ctx.lineTo(w / 2, h);
    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.setLineDash([]); // Reset
  };

  const getCoordinates = (e) => {
    const rect = canvasRef.current.getBoundingClientRect();
    const x = (e.clientX || e.touches[0].clientX) - rect.left;
    const y = (e.clientY || e.touches[0].clientY) - rect.top;
    return { x, y };
  };

  const isMyHalf = (x) => {
    const mid = canvasRef.current.width / 2;
    if (role === 'creator') return x < mid;
    return x > mid;
  };

  const startDrawing = (e) => {
    const { x, y } = getCoordinates(e);
    if (!isMyHalf(x)) return;

    setStartPos({ x, y });
    setIsDrawing(true);
    
    if (tool === 'pen' || tool === 'eraser') {
      contextRef.current.beginPath();
      contextRef.current.moveTo(x, y);
      contextRef.current.strokeStyle = tool === 'eraser' ? '#ffffff' : brushColor;
      contextRef.current.lineWidth = brushSize;
    }
  };

  const draw = (e) => {
    if (!isDrawing) return;
    const { x, y } = getCoordinates(e);
    if (!isMyHalf(x)) {
      stopDrawing();
      return;
    }

    const ctx = contextRef.current;

    if (tool === 'pen' || tool === 'eraser') {
      const prevX = startPos.x;
      const prevY = startPos.y;
      
      ctx.lineTo(x, y);
      ctx.stroke();
      
      socket.emit('draw-event', {
        roomCode,
        x, y, prevX, prevY,
        color: tool === 'eraser' ? '#ffffff' : brushColor,
        size: brushSize,
        tool: 'pen'
      });
      
      setStartPos({ x, y });
    }
  };

  const stopDrawing = (e) => {
    if (!isDrawing) return;
    
    if (tool !== 'pen' && tool !== 'eraser') {
      const { x, y } = getCoordinates(e);
      drawShape(contextRef.current, startPos.x, startPos.y, x, y, tool, brushColor, brushSize);
      
      socket.emit('draw-event', {
        roomCode,
        x, y,
        prevX: startPos.x,
        prevY: startPos.y,
        color: brushColor,
        size: brushSize,
        tool
      });
    }

    setIsDrawing(false);
  };

  const drawShape = (ctx, x1, y1, x2, y2, shapeTool, color, size) => {
    ctx.beginPath();
    ctx.strokeStyle = color;
    ctx.lineWidth = size;
    
    if (shapeTool === 'rectangle') {
      ctx.strokeRect(x1, y1, x2 - x1, y2 - y1);
    } else if (shapeTool === 'circle') {
      const radius = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
      ctx.arc(x1, y1, radius, 0, 2 * Math.PI);
      ctx.stroke();
    } else if (shapeTool === 'line') {
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.stroke();
    }
  };

  const drawRemote = (data) => {
    const ctx = contextRef.current;
    const { x, y, prevX, prevY, color, size, tool: remoteTool } = data;
    
    ctx.strokeStyle = color;
    ctx.lineWidth = size;
    
    if (remoteTool === 'pen') {
      ctx.beginPath();
      ctx.moveTo(prevX, prevY);
      ctx.lineTo(x, y);
      ctx.stroke();
    } else {
      drawShape(ctx, prevX, prevY, x, y, remoteTool, color, size);
    }
  };

  const clearCanvas = (emit = true) => {
    const canvas = canvasRef.current;
    contextRef.current.clearRect(0, 0, canvas.width, canvas.height);
    drawDivider(contextRef.current, canvas.width, canvas.height);
    if (emit) socket.emit('clear-canvas', { roomCode });
  };

  const handleRefUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setReferenceImg(event.target.result);
        socket.emit('update-reference', { roomCode, image: event.target.result });
      };
      reader.readAsDataURL(file);
    }
  };

  const saveDrawing = async () => {
    const canvas = canvasRef.current;
    const image = canvas.toDataURL('image/png');
    
    // Save to user profile
    try {
      await axios.post('/api/drawings/save', {
        image,
        partner,
        username: user.username
      });
      
      // Download to device
      const link = document.createElement('a');
      link.download = `dual-doodle-${roomCode}.png`;
      link.href = image;
      link.click();
      alert('Drawing saved and downloaded!');
    } catch (err) {
      alert('Failed to save drawing to profile, but downloading to device anyway.');
      const link = document.createElement('a');
      link.download = `dual-doodle-${roomCode}.png`;
      link.href = image;
      link.click();
    }
  };

  const endSession = () => {
    if (window.confirm('Are you sure you want to end the session for everyone?')) {
      socket.emit('end-session', { roomCode });
      navigate('/');
    }
  };

  return (
    <div className="h-screen flex flex-col bg-slate-900 text-white overflow-hidden">
      {/* Header */}
      <header className="px-6 py-4 bg-slate-800 flex justify-between items-center shadow-lg">
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2">
            <Palette className="w-6 h-6 text-indigo-400" />
            <h2 className="text-xl font-bold">Dual Doodle</h2>
          </div>
          <div className="px-3 py-1 bg-slate-700 rounded-full flex items-center text-sm font-mono">
            <span className="text-slate-400 mr-2">ROOM:</span> {roomCode}
          </div>
          <div className="flex items-center space-x-2 text-sm text-slate-300">
            <Users className="w-4 h-4" />
            <span>Partner: {partner || 'Waiting...'}</span>
          </div>
        </div>
        
        <div className="flex items-center space-x-3">
          <button 
            onClick={saveDrawing}
            className="flex items-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors font-semibold"
          >
            <Download className="w-4 h-4 mr-2" />
            Save & Download
          </button>
          <button 
            onClick={endSession}
            className="flex items-center px-4 py-2 bg-red-500 hover:bg-red-600 rounded-lg transition-colors font-semibold"
          >
            <XCircle className="w-4 h-4 mr-2" />
            End Session
          </button>
        </div>
      </header>

      <main className="flex-1 flex overflow-hidden">
        {/* Left Toolbar */}
        <aside className="w-20 bg-slate-800 border-r border-slate-700 flex flex-col items-center py-6 space-y-6">
          <ToolButton active={tool === 'pen'} onClick={() => setTool('pen')} icon={<Palette />} title="Pen" />
          <ToolButton active={tool === 'eraser'} onClick={() => setTool('eraser')} icon={<Eraser />} title="Eraser" />
          <ToolButton active={tool === 'line'} onClick={() => setTool('line')} icon={<Minus />} title="Line" />
          <ToolButton active={tool === 'rectangle'} onClick={() => setTool('rectangle')} icon={<Square />} title="Rectangle" />
          <ToolButton active={tool === 'circle'} onClick={() => setTool('circle')} icon={<Circle />} title="Circle" />
          
          <div className="h-px w-10 bg-slate-700 my-2"></div>
          
          <div className="flex flex-col items-center space-y-3">
            <input 
              type="color" 
              value={brushColor} 
              onChange={(e) => setBrushColor(e.target.value)}
              className="w-10 h-10 rounded cursor-pointer bg-transparent border-none"
            />
            <input 
              type="range" 
              min="1" 
              max="50" 
              value={brushSize} 
              onChange={(e) => setBrushSize(parseInt(e.target.value))}
              className="w-16 h-1 accent-indigo-500"
            />
            <span className="text-xs font-mono">{brushSize}px</span>
          </div>

          <div className="h-px w-10 bg-slate-700 my-2"></div>

          <button 
            onClick={() => clearCanvas()}
            className="p-3 text-slate-400 hover:text-red-400 transition-colors"
            title="Clear Canvas"
          >
            <Trash2 className="w-6 h-6" />
          </button>
        </aside>

        {/* Canvas Area */}
        <section className="flex-1 relative flex flex-col items-center justify-center p-8">
          <div className="mb-4 text-slate-400 flex space-x-40 font-semibold">
            <span className={role === 'creator' ? "text-indigo-400" : ""}>
              {role === 'creator' ? "YOUR HALF (Left)" : "PARTNER'S HALF (Left)"}
            </span>
            <span className={role === 'joiner' ? "text-indigo-400" : ""}>
              {role === 'joiner' ? "YOUR HALF (Right)" : "PARTNER'S HALF (Right)"}
            </span>
          </div>
          
          <div className="canvas-container bg-white rounded-lg shadow-2xl overflow-hidden cursor-crosshair">
            <canvas
              ref={canvasRef}
              onMouseDown={startDrawing}
              onMouseMove={draw}
              onMouseUp={stopDrawing}
              onMouseLeave={stopDrawing}
              onTouchStart={startDrawing}
              onTouchMove={draw}
              onTouchEnd={stopDrawing}
              className="block"
            />
          </div>
        </section>

        {/* Right Reference Panel */}
        <aside className="w-64 bg-slate-800 border-l border-slate-700 flex flex-col p-4 overflow-y-auto">
          <h3 className="text-sm font-bold text-slate-400 mb-4 uppercase tracking-wider flex items-center">
            <ImageIcon className="w-4 h-4 mr-2" /> Reference
          </h3>
          
          <div className="aspect-square bg-slate-900 rounded-lg border-2 border-dashed border-slate-700 flex items-center justify-center relative overflow-hidden mb-4">
            {referenceImg ? (
              <img src={referenceImg} alt="Reference" className="max-w-full max-h-full object-contain" />
            ) : (
              <p className="text-slate-600 text-xs text-center p-4">No reference image uploaded</p>
            )}
          </div>

          <label className="flex items-center justify-center px-4 py-2 bg-slate-700 hover:bg-slate-600 rounded-lg cursor-pointer transition-colors text-sm font-semibold">
            <ImageIcon className="w-4 h-4 mr-2" />
            Upload Reference
            <input type="file" className="hidden" accept="image/*" onChange={handleRefUpload} />
          </label>
          
          <div className="mt-8">
            <h3 className="text-xs font-bold text-slate-400 mb-4 uppercase tracking-wider">Instructions</h3>
            <ul className="text-xs text-slate-400 space-y-2 list-disc pl-4">
              <li>Creator draws on the left half.</li>
              <li>Joiner draws on the right half.</li>
              <li>Upload a reference image to sync with your partner.</li>
              <li>Save your masterpiece to your profile and device.</li>
            </ul>
          </div>
        </aside>
      </main>
    </div>
  );
};

const ToolButton = ({ active, onClick, icon, title }) => (
  <button 
    onClick={onClick}
    className={`p-3 rounded-xl transition-all ${active ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/50' : 'text-slate-400 hover:bg-slate-700 hover:text-white'}`}
    title={title}
  >
    {React.cloneElement(icon, { className: "w-6 h-6" })}
  </button>
);

export default DrawingBoard;

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Plus, Users, History, LogOut, ChevronRight } from 'lucide-react';

const Dashboard = ({ user, onLogout }) => {
  const [roomCode, setRoomCode] = useState('');
  const [drawings, setDrawings] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchDrawings = async () => {
      try {
        const res = await axios.get('/api/user/drawings', {
          headers: { Authorization: `Bearer ${user.token}` }
        });
        setDrawings(res.data);
      } catch (err) {
        console.error('Failed to fetch drawings');
      }
    };
    fetchDrawings();
  }, [user.token]);

  const handleCreateSession = () => {
    const code = Math.random().toString(36).substring(2, 8).toUpperCase();
    navigate(`/draw/${code}?role=creator`);
  };

  const handleJoinSession = (e) => {
    e.preventDefault();
    if (roomCode.trim()) {
      navigate(`/draw/${roomCode.toUpperCase()}?role=joiner`);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <header className="flex justify-between items-center mb-12">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Hello, {user.username}!</h1>
          <p className="text-slate-500">Ready for some collaborative art?</p>
        </div>
        <button 
          onClick={onLogout}
          className="flex items-center px-4 py-2 text-slate-600 hover:text-red-600 transition-colors"
        >
          <LogOut className="w-5 h-5 mr-2" />
          Logout
        </button>
      </header>

      <div className="grid md:grid-cols-2 gap-8 mb-12">
        {/* Create Session */}
        <div className="p-8 bg-indigo-600 rounded-3xl text-white shadow-xl shadow-indigo-200">
          <div className="p-3 bg-white/20 w-fit rounded-2xl mb-4">
            <Plus className="w-8 h-8" />
          </div>
          <h2 className="text-2xl font-bold mb-2">New Session</h2>
          <p className="text-indigo-100 mb-6">Create a room and share the code with a friend to start drawing together.</p>
          <button 
            onClick={handleCreateSession}
            className="w-full py-3 bg-white text-indigo-600 rounded-xl font-bold hover:bg-indigo-50 transition-colors"
          >
            Create Room
          </button>
        </div>

        {/* Join Session */}
        <div className="p-8 bg-white rounded-3xl border border-slate-200 shadow-sm">
          <div className="p-3 bg-indigo-100 w-fit rounded-2xl mb-4">
            <Users className="w-8 h-8 text-indigo-600" />
          </div>
          <h2 className="text-2xl font-bold mb-2 text-slate-800">Join Session</h2>
          <p className="text-slate-500 mb-6">Enter a room code to join an existing session.</p>
          <form onSubmit={handleJoinSession} className="flex gap-2">
            <input 
              type="text" 
              placeholder="Enter Code"
              className="flex-1 px-4 py-3 border rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 uppercase font-mono tracking-widest"
              value={roomCode}
              onChange={(e) => setRoomCode(e.target.value)}
            />
            <button 
              type="submit"
              className="px-6 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-colors"
            >
              Join
            </button>
          </form>
        </div>
      </div>

      {/* Previous Drawings */}
      <section>
        <div className="flex items-center mb-6">
          <History className="w-6 h-6 mr-2 text-indigo-600" />
          <h2 className="text-2xl font-bold text-slate-800">Your Masterpieces</h2>
        </div>
        
        {drawings.length === 0 ? (
          <div className="text-center py-20 bg-slate-100 rounded-3xl border-2 border-dashed border-slate-300">
            <p className="text-slate-500">No drawings yet. Start your first session!</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {drawings.map((drawing, idx) => (
              <div key={idx} className="group bg-white rounded-2xl border border-slate-200 overflow-hidden hover:shadow-md transition-shadow">
                <div className="aspect-video bg-slate-100 relative overflow-hidden">
                  <img 
                    src={drawing.image} 
                    alt="Drawing" 
                    className="w-full h-full object-contain p-2"
                  />
                </div>
                <div className="p-4 flex justify-between items-center">
                  <div>
                    <p className="font-semibold text-slate-800">Collaborated with {drawing.partner || 'Unknown'}</p>
                    <p className="text-xs text-slate-500">{new Date(drawing.date).toLocaleDateString()}</p>
                  </div>
                  <a 
                    href={drawing.image} 
                    download={`drawing-${idx}.png`}
                    className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                  >
                    <ChevronRight className="w-5 h-5" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};

export default Dashboard;

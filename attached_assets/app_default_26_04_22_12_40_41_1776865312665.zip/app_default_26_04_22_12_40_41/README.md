# Dual Doodle - Collaborative Split-Screen Drawing

Dual Doodle is a real-time, collaborative drawing platform where two artists can work together on a single canvas. The canvas is divided into two halves, with each participant controlling one side while seeing the other's work in real-time.

## Features

-   **User Authentication**: Secure login and registration with JWT.
-   **Split-Screen Canvas**: Exclusive drawing zones for each user (Left for creator, Right for joiner).
-   **Real-Time Sync**: Instant synchronization using Socket.io.
-   **Drawing Tools**: Pen, Eraser, Shapes (Line, Rectangle, Circle), color picker, and brush size.
-   **Reference Support**: Upload a reference image that appears on both users' screens.
-   **Session History**: Save your collaborative artworks to your profile.
-   **Export**: Download the final drawing to your device as a PNG.

## Prerequisites

-   **Node.js**: v16 or higher
-   **MongoDB**: A local instance running on `mongodb://localhost:27017/dualdoodle` or a MongoDB Atlas URI.

## Installation

1.  **Extract the project** files.
2.  **Install dependencies**:
    
import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import mongoose from 'mongoose';
import cors from 'cors';
import dotenv from 'dotenv';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';

dotenv.config();

const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

app.use(cors());
app.use(express.json({ limit: '10mb' }));

// --- MongoDB Schemas ---

const userSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  drawings: [{ 
    image: String, 
    date: { type: Date, default: Date.now },
    partner: String 
  }]
});

const User = mongoose.model('User', userSchema);

const sessionSchema = new mongoose.Schema({
  roomCode: { type: String, required: true, unique: true },
  creator: { type: String, required: true },
  joiner: { type: String },
  referenceImage: { type: String },
  isActive: { type: Boolean, default: true }
});

const Session = mongoose.model('Session', sessionSchema);

// --- Auth Routes ---

app.post('/api/auth/register', async (req, res) => {
  try {
    const { username, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = new User({ username, password: hashedPassword });
    await user.save();
    const token = jwt.sign({ id: user._id, username }, process.env.JWT_SECRET);
    res.json({ token, username });
  } catch (err) {
    res.status(400).json({ error: "Username already exists" });
  }
});

app.post('/api/auth/login', async (req, res) => {
  const { username, password } = req.body;
  const user = await User.findOne({ username });
  if (user && await bcrypt.compare(password, user.password)) {
    const token = jwt.sign({ id: user._id, username }, process.env.JWT_SECRET);
    res.json({ token, username });
  } else {
    res.status(400).json({ error: "Invalid credentials" });
  }
});

app.get('/api/user/drawings', async (req, res) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: "Unauthorized" });
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id);
    res.json(user.drawings.reverse());
  } catch (err) {
    res.status(401).json({ error: "Invalid token" });
  }
});

app.post('/api/drawings/save', async (req, res) => {
  const { image, partner, username } = req.body;
  try {
    await User.findOneAndUpdate(
      { username },
      { $push: { drawings: { image, partner } } }
    );
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: "Failed to save" });
  }
});

// --- Socket.io Logic ---

const rooms = new Map();

io.on('connection', (socket) => {
  console.log('User connected:', socket.id);

  socket.on('create-room', async ({ roomCode, username }) => {
    socket.join(roomCode);
    rooms.set(roomCode, { creator: username, creatorSocket: socket.id });
    console.log(`Room ${roomCode} created by ${username}`);
  });

  socket.on('join-room', async ({ roomCode, username }) => {
    const room = rooms.get(roomCode);
    if (room) {
      if (room.joiner) {
        socket.emit('error', 'Room is full');
        return;
      }
      room.joiner = username;
      room.joinerSocket = socket.id;
      socket.join(roomCode);
      io.to(roomCode).emit('user-joined', { 
        creator: room.creator, 
        joiner: username 
      });
      console.log(`${username} joined room ${roomCode}`);
    } else {
      socket.emit('error', 'Room not found');
    }
  });

  socket.on('draw-event', (data) => {
    // data contains: roomCode, x, y, prevX, prevY, color, size, tool, isLeftHalf
    socket.to(data.roomCode).emit('remote-draw', data);
  });

  socket.on('update-reference', ({ roomCode, image }) => {
    socket.to(roomCode).emit('reference-updated', image);
  });

  socket.on('clear-canvas', ({ roomCode }) => {
    socket.to(roomCode).emit('remote-clear');
  });

  socket.on('end-session', ({ roomCode }) => {
    io.to(roomCode).emit('session-ended');
    rooms.delete(roomCode);
  });

  socket.on('disconnect', () => {
    console.log('User disconnected');
  });
});

// --- Start Server ---

const PORT = process.env.PORT || 5000;
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/dualdoodle';

mongoose.connect(MONGODB_URI)
  .then(() => {
    console.log('Connected to MongoDB');
    httpServer.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  })
  .catch(err => console.error('MongoDB connection error:', err));
